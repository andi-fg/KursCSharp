﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Delegate
{
    class Einkaufswagen
    {
        public delegate void PreisOhneRabatt(double subtotal);
        public List<Produkt> Items { get; set; } = new List<Produkt>();

        public double Total(PreisOhneRabatt preisOhneRabatt)
        {
            double total = Items.Sum(x => x.Preis);

            preisOhneRabatt(total);

            //Rabatt
            if(total > 100)
            {
                return total * 0.9;
            }else if(total > 50)
            {
                return total * 0.95;
            }
            return total;
        }
    }
}
