﻿using System;

namespace Aufgabe_Delegate
{
    class Program
    {
        static Einkaufswagen wagen = new Einkaufswagen();
        static void Main(string[] args)
        {
            InitWagen();

            Console.WriteLine($"Total des Wagen ist: {wagen.Total(TotalAlert):C2}");

            Console.WriteLine();
            Console.Write("Klick ein Knopf um die Applikation zu schliessen...");
            Console.ReadKey();
        }

        private static void TotalAlert(double total)
        {
            Console.WriteLine($"Das Total ohne Rabatt ist {total:C2}");
        }

        private static void InitWagen()
        {
            wagen.Items.Add(new Produkt { ItemName = "Milch", Preis = 1.5 });
            wagen.Items.Add(new Produkt { ItemName = "Banane", Preis = 2.9 });
            wagen.Items.Add(new Produkt { ItemName = "Erdebeere", Preis = 4.25 });
            wagen.Items.Add(new Produkt { ItemName = "Müsli", Preis = 0.8 });
        }
    }
}
