﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Aufgabe_Delegate
{
    class Einkaufswagen
    {
        public List<Produkt> Items { get; set; } = new List<Produkt>();

        public double Total()
        {
            double total = Items.Sum(x => x.Preis);
            //Rabat
            if(total > 100)
            {
                return total * 0.9;
            }else if(total > 50)
            {
                return total * 0.95;
            }
            return total;
        }
    }
}
